﻿namespace SkillsManagementSystem
{
    partial class UpdateEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label9 = new Label();
            button2 = new Button();
            button1 = new Button();
            numCommunicationRate = new NumericUpDown();
            label8 = new Label();
            label7 = new Label();
            Position = new ComboBox();
            label6 = new Label();
            cmbEnglishLevel = new ComboBox();
            label5 = new Label();
            txtUsername = new TextBox();
            label4 = new Label();
            txtPassword = new TextBox();
            label3 = new Label();
            txtFullName = new TextBox();
            label2 = new Label();
            label1 = new Label();
            Experience = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)numCommunicationRate).BeginInit();
            SuspendLayout();
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 9F, FontStyle.Italic, GraphicsUnit.Point, 204);
            label9.Location = new Point(15, 10);
            label9.Name = "label9";
            label9.Size = new Size(120, 20);
            label9.TabIndex = 40;
            label9.Text = "Update Employee";
            // 
            // button2
            // 
            button2.BackColor = SystemColors.MenuHighlight;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold);
            button2.ForeColor = Color.White;
            button2.Location = new Point(347, 522);
            button2.Name = "button2";
            button2.Size = new Size(133, 69);
            button2.TabIndex = 39;
            button2.Text = "Update";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Silver;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(137, 522);
            button1.Name = "button1";
            button1.Size = new Size(133, 69);
            button1.TabIndex = 38;
            button1.Text = "Clear";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // numCommunicationRate
            // 
            numCommunicationRate.BorderStyle = BorderStyle.None;
            numCommunicationRate.Location = new Point(265, 431);
            numCommunicationRate.Maximum = new decimal(new int[] { 10, 0, 0, 0 });
            numCommunicationRate.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numCommunicationRate.Name = "numCommunicationRate";
            numCommunicationRate.Size = new Size(150, 23);
            numCommunicationRate.TabIndex = 37;
            numCommunicationRate.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label8.Location = new Point(56, 423);
            label8.Name = "label8";
            label8.Size = new Size(156, 56);
            label8.TabIndex = 36;
            label8.Text = "Communication\r\n rate";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label7.Location = new Point(55, 359);
            label7.Name = "label7";
            label7.Size = new Size(110, 28);
            label7.TabIndex = 34;
            label7.Text = "Experience";
            // 
            // Position
            // 
            Position.FormattingEnabled = true;
            Position.Location = new Point(264, 301);
            Position.Name = "Position";
            Position.Size = new Size(151, 28);
            Position.TabIndex = 33;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label6.Location = new Point(55, 301);
            label6.Name = "label6";
            label6.Size = new Size(85, 28);
            label6.TabIndex = 32;
            label6.Text = "Position";
            // 
            // cmbEnglishLevel
            // 
            cmbEnglishLevel.FormattingEnabled = true;
            cmbEnglishLevel.Location = new Point(264, 242);
            cmbEnglishLevel.Name = "cmbEnglishLevel";
            cmbEnglishLevel.Size = new Size(151, 28);
            cmbEnglishLevel.TabIndex = 31;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label5.Location = new Point(55, 242);
            label5.Name = "label5";
            label5.Size = new Size(130, 28);
            label5.TabIndex = 30;
            label5.Text = "English Level";
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(174, 98);
            txtUsername.Multiline = true;
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(241, 35);
            txtUsername.TabIndex = 29;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label4.Location = new Point(55, 105);
            label4.Name = "label4";
            label4.Size = new Size(104, 28);
            label4.TabIndex = 28;
            label4.Text = "Username";
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(174, 170);
            txtPassword.Multiline = true;
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(241, 35);
            txtPassword.TabIndex = 27;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label3.Location = new Point(55, 177);
            label3.Name = "label3";
            label3.Size = new Size(97, 28);
            label3.TabIndex = 26;
            label3.Text = "Password";
            // 
            // txtFullName
            // 
            txtFullName.Location = new Point(174, 41);
            txtFullName.Multiline = true;
            txtFullName.Name = "txtFullName";
            txtFullName.Size = new Size(241, 35);
            txtFullName.TabIndex = 25;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.Location = new Point(55, 48);
            label2.Name = "label2";
            label2.Size = new Size(104, 28);
            label2.TabIndex = 24;
            label2.Text = "Full Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Cursor = Cursors.Hand;
            label1.Font = new Font("Microsoft JhengHei", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(556, -2);
            label1.Name = "label1";
            label1.Size = new Size(44, 43);
            label1.TabIndex = 23;
            label1.Text = "×";
            label1.Click += label1_Click;
            // 
            // Experience
            // 
            Experience.FormattingEnabled = true;
            Experience.Location = new Point(264, 359);
            Experience.Name = "Experience";
            Experience.Size = new Size(151, 28);
            Experience.TabIndex = 41;
            // 
            // UpdateEmployee
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(599, 616);
            Controls.Add(Experience);
            Controls.Add(label9);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(numCommunicationRate);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(Position);
            Controls.Add(label6);
            Controls.Add(cmbEnglishLevel);
            Controls.Add(label5);
            Controls.Add(txtUsername);
            Controls.Add(label4);
            Controls.Add(txtPassword);
            Controls.Add(label3);
            Controls.Add(txtFullName);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "UpdateEmployee";
            Text = "UpdateEmployee";
            ((System.ComponentModel.ISupportInitialize)numCommunicationRate).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label9;
        private Button button2;
        private Button button1;
        private NumericUpDown numCommunicationRate;
        private Label label8;
        private Label label7;
        private ComboBox Position;
        private Label label6;
        private ComboBox cmbEnglishLevel;
        private Label label5;
        private TextBox txtUsername;
        private Label label4;
        private TextBox txtPassword;
        private Label label3;
        private TextBox txtFullName;
        private Label label2;
        private Label label1;
        private ComboBox Experience;
        private Button UploadCertificate;
    }
}