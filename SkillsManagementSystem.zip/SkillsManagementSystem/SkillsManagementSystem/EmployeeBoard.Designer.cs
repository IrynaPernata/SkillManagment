﻿namespace SkillsManagementSystem
{
    partial class EmployeeBoard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeBoard));
            label8 = new Label();
            label7 = new Label();
            AddEmployee = new Button();
            label2 = new Label();
            dataGridView1 = new DataGridView();
            employeeBindingSource = new BindingSource(components);
            Delete = new Button();
            Update = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)employeeBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(112, 170);
            label8.Name = "label8";
            label8.Size = new Size(17, 20);
            label8.TabIndex = 12;
            label8.Text = "0";
            label8.Click += label8_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label7.Location = new Point(54, 166);
            label7.Name = "label7";
            label7.Size = new Size(52, 25);
            label7.TabIndex = 11;
            label7.Text = "Total";
            // 
            // AddEmployee
            // 
            AddEmployee.BackColor = Color.FromArgb(0, 141, 218);
            AddEmployee.Cursor = Cursors.Hand;
            AddEmployee.FlatAppearance.BorderSize = 0;
            AddEmployee.FlatAppearance.MouseOverBackColor = Color.FromArgb(34, 109, 170);
            AddEmployee.FlatStyle = FlatStyle.Flat;
            AddEmployee.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            AddEmployee.ForeColor = SystemColors.ButtonHighlight;
            AddEmployee.Location = new Point(54, 108);
            AddEmployee.Name = "AddEmployee";
            AddEmployee.Size = new Size(169, 43);
            AddEmployee.TabIndex = 10;
            AddEmployee.Text = "Add New Employee";
            AddEmployee.UseVisualStyleBackColor = false;
            AddEmployee.Click += AddEmployee_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 26F, FontStyle.Bold);
            label2.Location = new Point(41, 29);
            label2.Name = "label2";
            label2.Size = new Size(213, 60);
            label2.TabIndex = 9;
            label2.Text = "My Team";
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(41, 217);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(770, 430);
            dataGridView1.TabIndex = 13;
            dataGridView1.CellMouseDoubleClick += dataGridView1_CellMouseDoubleClick;
            // 
            // Delete
            // 
            Delete.BackColor = Color.Firebrick;
            Delete.Cursor = Cursors.Hand;
            Delete.FlatAppearance.BorderSize = 0;
            Delete.FlatAppearance.MouseOverBackColor = Color.FromArgb(34, 109, 170);
            Delete.FlatStyle = FlatStyle.Flat;
            Delete.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            Delete.ForeColor = SystemColors.ButtonHighlight;
            Delete.Location = new Point(700, 159);
            Delete.Name = "Delete";
            Delete.Size = new Size(111, 43);
            Delete.TabIndex = 14;
            Delete.Text = "Delete";
            Delete.UseVisualStyleBackColor = false;
            Delete.Click += Delete_Click;
            // 
            // Update
            // 
            Update.BackColor = Color.LimeGreen;
            Update.Cursor = Cursors.Hand;
            Update.FlatAppearance.BorderSize = 0;
            Update.FlatAppearance.MouseOverBackColor = Color.FromArgb(34, 109, 170);
            Update.FlatStyle = FlatStyle.Flat;
            Update.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            Update.ForeColor = SystemColors.ButtonHighlight;
            Update.Location = new Point(570, 159);
            Update.Name = "Update";
            Update.Size = new Size(111, 43);
            Update.TabIndex = 15;
            Update.Text = "Edit";
            Update.UseVisualStyleBackColor = false;
            Update.Click += Update_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.ErrorImage = Properties.Resources.refresh_480px;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.InitialImage = Properties.Resources.refresh_480px;
            pictureBox1.Location = new Point(487, 152);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(50, 50);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 16;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // EmployeeBoard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(pictureBox1);
            Controls.Add(Update);
            Controls.Add(Delete);
            Controls.Add(dataGridView1);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(AddEmployee);
            Controls.Add(label2);
            Name = "EmployeeBoard";
            Size = new Size(856, 672);
            Load += EmployeeBoard_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)employeeBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label8;
        private Label label7;
        private Button AddEmployee;
        private Label label2;
        private DataGridView dataGridView1;
        private Button Delete;
        private Button Update;
        private PictureBox pictureBox1;
        private BindingSource employeeBindingSource;
    }
}
