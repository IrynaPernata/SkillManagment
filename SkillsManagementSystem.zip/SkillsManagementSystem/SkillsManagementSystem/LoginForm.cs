using System;
using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.VisualBasic.Logging;

namespace SkillsManagementSystem
{
    public partial class LoginForm : Form
    {
        string connect = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Acer Nitro 5\LocalDB\employee.mdf"";Integrated Security=True;Connect Timeout=30";
        public LoginForm()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           passwordTextBox.PasswordChar = ShowPasswordBox.Checked ? '\0' : '*';
        }

        private void usernameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = usernameTextBox.Text;
            string password = passwordTextBox.Text;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please fill all blank fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                DataRow employeeData = GetEmployeeByUsernameAndPassword(login, password);

                if (employeeData != null)
                {
                    int employeeId = Convert.ToInt32(employeeData["id"]);
                    string fullName = Convert.ToString(employeeData["full_name"]);
                    string username = Convert.ToString(employeeData["username"]);
                    string englishLevel = Convert.ToString(employeeData["english_level"]);
                    string position = Convert.ToString(employeeData["position"]);
                    string experience = Convert.ToString(employeeData["experience"]);

                    EmployeeProfileForm profileForm = new EmployeeProfileForm(employeeId, fullName, username, englishLevel, position, experience);
                    profileForm.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Incorrect Username/Password", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    


        private DataRow GetEmployeeByUsernameAndPassword(string username, string password)
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string query = @"
                SELECT 
                    e.id, 
                    e.full_name, 
                    e.username, 
                    e.password_hash,
                    el.level_name AS english_level, 
                    p.position_name AS position, 
                    ex.experience_name AS experience, 
                    e.communication_skills_id 
                FROM 
                    employees e
                    JOIN english_levels el ON e.english_level_id = el.id
                    JOIN positions p ON e.position_id = p.id
                    JOIN experiences ex ON e.experience_id = ex.id
                WHERE 
                    e.username = @username AND e.password_hash = @password";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable employeeTable = new DataTable();
                adapter.Fill(employeeTable);

                if (employeeTable.Rows.Count > 0)
                {
                    return employeeTable.Rows[0];
                }
                else
                {
                    return null;
                }
            }
        }



private void ImHR_Click(object sender, EventArgs e)
        {
            HRForm registerForm = new HRForm();
            registerForm.Show();
            this.Hide();
        }


        private void ShowPasswordBox_CheckedChanged(object sender, EventArgs e)
        {
            passwordTextBox.PasswordChar = ShowPasswordBox.Checked ? '\0' : '*';
        }
    }
}
