﻿namespace SkillsManagementSystem
{
    partial class LoginForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            panel1 = new Panel();
            label4 = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            usernameTextBox = new TextBox();
            passwordTextBox = new TextBox();
            PasswordLabel = new Label();
            ShowPasswordBox = new CheckBox();
            login = new Button();
            ImHR = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(153, 188, 133);
            panel1.BackgroundImage = (Image)resources.GetObject("panel1.BackgroundImage");
            panel1.BackgroundImageLayout = ImageLayout.None;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(label4);
            panel1.Dock = DockStyle.Left;
            panel1.ForeColor = Color.DarkSeaGreen;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(223, 400);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.FromArgb(0, 0, 0, 0);
            label4.Font = new Font("Tahoma", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label4.ForeColor = Color.Azure;
            label4.Location = new Point(16, 18);
            label4.Name = "label4";
            label4.Size = new Size(186, 102);
            label4.TabIndex = 0;
            label4.Text = "Skills \r\nManagement \r\nSystem";
            label4.Click += label4_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Cursor = Cursors.Hand;
            label1.Font = new Font("Microsoft JhengHei", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(532, -2);
            label1.Name = "label1";
            label1.Size = new Size(44, 43);
            label1.TabIndex = 1;
            label1.Text = "×";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.ForeColor = Color.FromArgb(0, 60, 67);
            label2.Location = new Point(245, 56);
            label2.Name = "label2";
            label2.Size = new Size(221, 35);
            label2.TabIndex = 2;
            label2.Text = "Login Account";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label3.ForeColor = Color.FromArgb(64, 64, 64);
            label3.Location = new Point(245, 121);
            label3.Name = "label3";
            label3.Size = new Size(99, 23);
            label3.TabIndex = 3;
            label3.Text = "Username";
            // 
            // usernameTextBox
            // 
            usernameTextBox.Cursor = Cursors.IBeam;
            usernameTextBox.Font = new Font("Microsoft YaHei", 10.2F);
            usernameTextBox.Location = new Point(245, 150);
            usernameTextBox.Multiline = true;
            usernameTextBox.Name = "usernameTextBox";
            usernameTextBox.Size = new Size(261, 35);
            usernameTextBox.TabIndex = 4;
            usernameTextBox.TextChanged += usernameTextBox_TextChanged;
            // 
            // passwordTextBox
            // 
            passwordTextBox.Cursor = Cursors.IBeam;
            passwordTextBox.Font = new Font("Microsoft YaHei", 10.2F);
            passwordTextBox.Location = new Point(245, 225);
            passwordTextBox.Multiline = true;
            passwordTextBox.Name = "passwordTextBox";
            passwordTextBox.Size = new Size(261, 35);
            passwordTextBox.TabIndex = 6;
            passwordTextBox.TextChanged += textBox1_TextChanged;
            // 
            // PasswordLabel
            // 
            PasswordLabel.AutoSize = true;
            PasswordLabel.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            PasswordLabel.ForeColor = Color.FromArgb(64, 64, 64);
            PasswordLabel.Location = new Point(245, 196);
            PasswordLabel.Name = "PasswordLabel";
            PasswordLabel.Size = new Size(98, 23);
            PasswordLabel.TabIndex = 5;
            PasswordLabel.Text = "Password";
            // 
            // ShowPasswordBox
            // 
            ShowPasswordBox.AutoSize = true;
            ShowPasswordBox.Cursor = Cursors.Hand;
            ShowPasswordBox.FlatStyle = FlatStyle.Popup;
            ShowPasswordBox.Font = new Font("Arial", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            ShowPasswordBox.ForeColor = Color.FromArgb(64, 64, 64);
            ShowPasswordBox.Location = new Point(384, 266);
            ShowPasswordBox.Name = "ShowPasswordBox";
            ShowPasswordBox.Size = new Size(119, 20);
            ShowPasswordBox.TabIndex = 7;
            ShowPasswordBox.Text = "Show Password";
            ShowPasswordBox.UseVisualStyleBackColor = true;
            ShowPasswordBox.CheckedChanged += ShowPasswordBox_CheckedChanged;
            // 
            // login
            // 
            login.BackColor = Color.FromArgb(19, 93, 102);
            login.Cursor = Cursors.Hand;
            login.FlatAppearance.BorderColor = Color.DarkSlateGray;
            login.FlatAppearance.MouseDownBackColor = Color.FromArgb(26, 77, 46);
            login.FlatStyle = FlatStyle.Flat;
            login.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            login.ForeColor = Color.White;
            login.Location = new Point(248, 311);
            login.Name = "login";
            login.Size = new Size(105, 52);
            login.TabIndex = 8;
            login.Text = "LOGIN";
            login.UseVisualStyleBackColor = false;
            login.Click += button1_Click;
            // 
            // ImHR
            // 
            ImHR.BackColor = Color.FromArgb(122, 178, 178);
            ImHR.Cursor = Cursors.Hand;
            ImHR.FlatAppearance.BorderColor = Color.DarkSlateGray;
            ImHR.FlatAppearance.BorderSize = 0;
            ImHR.FlatAppearance.MouseDownBackColor = Color.FromArgb(26, 77, 46);
            ImHR.FlatStyle = FlatStyle.Flat;
            ImHR.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            ImHR.ForeColor = Color.White;
            ImHR.Location = new Point(398, 311);
            ImHR.Name = "ImHR";
            ImHR.Size = new Size(105, 52);
            ImHR.TabIndex = 9;
            ImHR.Text = "I`m HR";
            ImHR.UseVisualStyleBackColor = false;
            ImHR.Click += ImHR_Click;
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Menu;
            ClientSize = new Size(575, 400);
            Controls.Add(ImHR);
            Controls.Add(login);
            Controls.Add(ShowPasswordBox);
            Controls.Add(passwordTextBox);
            Controls.Add(PasswordLabel);
            Controls.Add(usernameTextBox);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "LoginForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox usernameTextBox;
        private TextBox passwordTextBox;
        private Label PasswordLabel;
        private CheckBox ShowPasswordBox;
        private Button login;
        private Label label4;
        private Button ImHR;
    }
}
