﻿namespace SkillsManagementSystem
{
    partial class CourseAssignForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            listBoxAllEmployees = new ListBox();
            listBoxAssignedEmployees = new ListBox();
            btnRemove = new Button();
            btnAssign = new Button();
            lblCourseName = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Cursor = Cursors.Hand;
            label1.Font = new Font("Microsoft JhengHei", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(685, -7);
            label1.Name = "label1";
            label1.Size = new Size(44, 43);
            label1.TabIndex = 4;
            label1.Text = "×";
            label1.Click += label1_Click;
            // 
            // listBoxAllEmployees
            // 
            listBoxAllEmployees.FormattingEnabled = true;
            listBoxAllEmployees.Location = new Point(92, 44);
            listBoxAllEmployees.Name = "listBoxAllEmployees";
            listBoxAllEmployees.Size = new Size(534, 184);
            listBoxAllEmployees.TabIndex = 5;
            // 
            // listBoxAssignedEmployees
            // 
            listBoxAssignedEmployees.FormattingEnabled = true;
            listBoxAssignedEmployees.Location = new Point(92, 247);
            listBoxAssignedEmployees.Name = "listBoxAssignedEmployees";
            listBoxAssignedEmployees.Size = new Size(534, 184);
            listBoxAssignedEmployees.TabIndex = 6;
            // 
            // btnRemove
            // 
            btnRemove.BackColor = Color.OrangeRed;
            btnRemove.FlatAppearance.BorderSize = 0;
            btnRemove.FlatStyle = FlatStyle.Flat;
            btnRemove.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            btnRemove.ForeColor = Color.White;
            btnRemove.Location = new Point(190, 457);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(107, 52);
            btnRemove.TabIndex = 7;
            btnRemove.Text = "Remove";
            btnRemove.UseVisualStyleBackColor = false;
            btnRemove.Click += btnRemove_Click;
            // 
            // btnAssign
            // 
            btnAssign.BackColor = Color.DeepSkyBlue;
            btnAssign.FlatAppearance.BorderSize = 0;
            btnAssign.FlatStyle = FlatStyle.Flat;
            btnAssign.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            btnAssign.ForeColor = Color.White;
            btnAssign.Location = new Point(405, 457);
            btnAssign.Name = "btnAssign";
            btnAssign.Size = new Size(107, 52);
            btnAssign.TabIndex = 9;
            btnAssign.Text = "Asign";
            btnAssign.UseVisualStyleBackColor = false;
            btnAssign.Click += btnAssign_Click;
            // 
            // lblCourseName
            // 
            lblCourseName.AutoSize = true;
            lblCourseName.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            lblCourseName.Location = new Point(43, 10);
            lblCourseName.Name = "lblCourseName";
            lblCourseName.Size = new Size(79, 31);
            lblCourseName.TabIndex = 10;
            lblCourseName.Text = "label2";
            // 
            // CourseAssignForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(724, 540);
            Controls.Add(lblCourseName);
            Controls.Add(btnAssign);
            Controls.Add(btnRemove);
            Controls.Add(listBoxAssignedEmployees);
            Controls.Add(listBoxAllEmployees);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "CourseAssignForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CourseAssignForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ListBox listBoxAllEmployees;
        private ListBox listBoxAssignedEmployees;
        private Button btnRemove;
        private Button btnAssign;
        private Label lblCourseName;
    }
}