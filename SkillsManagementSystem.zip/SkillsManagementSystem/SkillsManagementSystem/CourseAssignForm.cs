﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SkillsManagementSystem
{
    public partial class CourseAssignForm : Form
    {
        private int _courseId;
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Acer Nitro 5\LocalDB\employee.mdf"";Integrated Security=True;Connect Timeout=30";
        public CourseAssignForm(int courseId)
        {
            InitializeComponent();
            _courseId = courseId;
            LoadEmployees();
            LoadAssignedEmployees();
            LoadCourseDetails();
        }
        private void LoadEmployees()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT id, full_name FROM employees";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable employeesTable = new DataTable();
                adapter.Fill(employeesTable);
                listBoxAllEmployees.DataSource = employeesTable;
                listBoxAllEmployees.DisplayMember = "full_name";
                listBoxAllEmployees.ValueMember = "id";
            }
        }
        private void LoadCourseDetails()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT course_name FROM courses WHERE course_id = @courseId";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@courseId", _courseId);

                conn.Open();
                string courseName = (string)cmd.ExecuteScalar();
                lblCourseName.Text = courseName;
            }
        }

        private void LoadAssignedEmployees()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"
                SELECT 
                    e.id, 
                    e.full_name 
                FROM 
                    employees e
                    JOIN assignments_courses ac ON e.id = ac.employee_id
                WHERE 
                    ac.course_id = @courseId";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@courseId", _courseId);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable assignedEmployeesTable = new DataTable();
                adapter.Fill(assignedEmployeesTable);
                listBoxAssignedEmployees.DataSource = assignedEmployeesTable;
                listBoxAssignedEmployees.DisplayMember = "full_name";
                listBoxAssignedEmployees.ValueMember = "id";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAssign_Click(object sender, EventArgs e)
        {
            if (listBoxAllEmployees.SelectedValue != null)
            {
                int employeeId = Convert.ToInt32(listBoxAllEmployees.SelectedValue);

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO assignments_courses (employee_id, course_id) VALUES (@employeeId, @courseId)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@employeeId", employeeId);
                    cmd.Parameters.AddWithValue("@courseId", _courseId);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }

                LoadAssignedEmployees();
            }
        }
        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (listBoxAssignedEmployees.SelectedValue != null)
            {
                int employeeId = Convert.ToInt32(listBoxAssignedEmployees.SelectedValue);

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM assignments_courses WHERE employee_id = @employeeId AND course_id = @courseId";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@employeeId", employeeId);
                    cmd.Parameters.AddWithValue("@courseId", _courseId);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }

                LoadAssignedEmployees();
            }
        }
    }
}
