﻿using Microsoft.Data.SqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace SkillsManagementSystem
{
    public partial class AddEmployee : Form
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Acer Nitro 5\LocalDB\employee.mdf"";Integrated Security=True;Connect Timeout=30");
        private List<string> photoFilePaths = new List<string>();
        public AddEmployee()
        {
            InitializeComponent();
            LoadEnglishLevels();
            LoadPositions();
        }

        private void LoadEnglishLevels()
        {
            try
            {
                connect.Open();
                string query = "SELECT id, level_name FROM english_levels";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connect);
                DataTable englishLevels = new DataTable();
                adapter.Fill(englishLevels);

                comboBox1.DisplayMember = "level_name";
                comboBox1.ValueMember = "id";
                comboBox1.DataSource = englishLevels;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
            finally
            {
                connect.Close();
            }
        }

        private void LoadPositions()
        {
            try
            {
                connect.Open();
                string query = "SELECT id, position_name FROM positions";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connect);
                DataTable positions = new DataTable();
                adapter.Fill(positions);

                comboBox2.DisplayMember = "position_name";
                comboBox2.ValueMember = "id";
                comboBox2.DataSource = positions;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
            finally
            {
                connect.Close();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            fullnameTextBox.Clear();
            usernameTextbox.Clear();
            passwordTextbox.Clear();
            comboBox1.SelectedIndex = -1;
            comboBox2.SelectedIndex = -1;
            numericUpDown1.Value = 0;
            numericUpDown2.Value = 1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(fullnameTextBox.Text) ||
              string.IsNullOrWhiteSpace(usernameTextbox.Text) ||
              string.IsNullOrWhiteSpace(passwordTextbox.Text) ||
              comboBox1.SelectedIndex == -1 ||
              comboBox2.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill in all the required fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                connect.Open();
                string query = "INSERT INTO employees (full_name, username, password_hash, english_level_id, position_id, experience_id, communication_skills_id) " +
                               "VALUES (@FullName, @Username, @PasswordHash, @EnglishLevelId, @PositionId, @ExperienceId, @CommunicationSkills)";

                using (SqlCommand cmd = new SqlCommand(query, connect))
                {
                    cmd.Parameters.AddWithValue("@FullName", fullnameTextBox.Text);
                    cmd.Parameters.AddWithValue("@Username", usernameTextbox.Text);
                    cmd.Parameters.AddWithValue("@PasswordHash", passwordTextbox.Text);
                    cmd.Parameters.AddWithValue("@EnglishLevelId", comboBox1.SelectedValue);
                    cmd.Parameters.AddWithValue("@PositionId", comboBox2.SelectedValue);
                    cmd.Parameters.AddWithValue("@ExperienceId", numericUpDown1.Value);
                    cmd.Parameters.AddWithValue("@CommunicationSkills", numericUpDown2.Value);


                    
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Employee added successfully!");
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
            finally
            {
                connect.Close();
            }
            
        }



        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void label5_Click(object sender, EventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

       
       
    }
}
