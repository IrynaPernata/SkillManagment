﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SkillsManagementSystem
{
    public partial class MainForm : Form
    {
        private EmployeeBoard employeeBoard;
        private CourcesWindow studyBoard;
        public MainForm()
        {
            InitializeComponent();
            this.Load += new EventHandler(MainForm_Load);
            lblStudy.Click += new EventHandler(lblStudy_Click);
            lblEmployee.Click += new EventHandler(lblEmployee_Click);
        }



        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult check = MessageBox.Show("Are you sure you want to logout?"
    , "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (check == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void AddEmployee_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {


        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            employeeBoard = new EmployeeBoard();
            studyBoard = new CourcesWindow();

            // Додавання UserControl до панелі
            panel2.Controls.Add(employeeBoard);
            panel2.Controls.Add(studyBoard);

            employeeBoard.Visible = false;
            studyBoard.Visible = false;

            lblStudy.Click += new EventHandler(lblStudy_Click);
            lblEmployee.Click += new EventHandler(lblEmployee_Click);

            employeeBoard.Dock = DockStyle.Fill;
            studyBoard.Dock = DockStyle.Fill;

            ShowUserControl(employeeBoard);
            lblEmployee.BackColor = Color.FromArgb(232, 237, 242);
            lblStudy.BackColor = Color.White;
        }

        private void lblStudy_Click(object sender, EventArgs e)
        {
            ShowUserControl(studyBoard);
            lblStudy.BackColor = Color.FromArgb(232, 237, 242);
            lblEmployee.BackColor = Color.White;
        }

        private void lblEmployee_Click(object sender, EventArgs e)
        {
            ShowUserControl(employeeBoard);
            lblEmployee.BackColor = Color.FromArgb(232, 237, 242);
            lblStudy.BackColor = Color.White;
        }

        private void ShowUserControl(UserControl userControl)
        {
            employeeBoard.Visible = false;
            studyBoard.Visible = false;

            // Робимо видимим тільки обраний UserControl
            userControl.Visible = true;
            userControl.BringToFront();
        }

        private void employeeBoard3_Load(object sender, EventArgs e)
        {

        }
    }



}
