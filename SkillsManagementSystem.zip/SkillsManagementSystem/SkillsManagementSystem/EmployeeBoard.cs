﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace SkillsManagementSystem
{
    public partial class EmployeeBoard : UserControl
    {
        public EmployeeBoard()
        {
            InitializeComponent();
          
        }

        private void EmployeeBoard_Load(object sender, EventArgs e)
        {
            if (!DesignMode) // Додаємо перевірку DesignMode
            {
                LoadEmployees();
                label8.Text = Convert.ToString(GetTotalEmployeesCount());
            }
        }
            public void LoadEmployees()
        {
               // string adminUsername = Properties.Settings.Default.LoggedInAdmin;

                using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Acer Nitro 5\LocalDB\employee.mdf"";Integrated Security=True;Connect Timeout=30"))
                {
                    string query = @"
                    SELECT 
                        e.id, 
                        e.full_name, 
                        e.username, 
                        el.level_name AS english_level, 
                        p.position_name AS position, 
                        ex.experience_name AS experience, 
                        e.communication_skills_id 
                    FROM 
                        employees e
                        JOIN english_levels el ON e.english_level_id = el.id
                        JOIN positions p ON e.position_id = p.id
                        JOIN experiences ex ON e.experience_id = ex.id
                    ";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    //adapter.SelectCommand.Parameters.AddWithValue("@adminUsername", adminUsername);

                    DataTable employeesTable = new DataTable();
                    adapter.Fill(employeesTable);

                    dataGridView1.DataSource = employeesTable;
                }
            }

       

        //private DataTable ConvertToDataTable(List<Employee> employees)
        //{
        //    DataTable table = new DataTable();
        //    table.Columns.Add("Id", typeof(int));
        //    table.Columns.Add("FullName", typeof(string));
        //    table.Columns.Add("Username", typeof(string));
        //    table.Columns.Add("EnglishLevel", typeof(string));
        //    table.Columns.Add("Position", typeof(string));
        //    table.Columns.Add("Experience", typeof(string));
        //    table.Columns.Add("CommunicationSkillsId", typeof(int));

        //    foreach (var employee in employees)
        //    {
        //        table.Rows.Add(employee.Id, employee.FullName, employee.Username, employee.EnglishLevel, employee.Position, employee.Experience, employee.CommunicationSkillsId);
        //    }

        //    return table;
        


        private void AddEmployee_Click(object sender, EventArgs e)
        {
           // string adminUsername = Properties.Settings.Default.LoggedInAdmin;
            AddEmployee newEmployee = new AddEmployee();
           newEmployee.Show();
                  }

        private void Delete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int employeeId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["id"].Value);
                DialogResult result = MessageBox.Show("Are you sure you want to delete this employee?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    DeleteEmployee(employeeId);
                    LoadEmployees(); 
                }
            }
            else
            {
                MessageBox.Show("Please select an employee to delete.");
            }
        }
        private void DeleteEmployee(int employeeId)
        {
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Acer Nitro 5\LocalDB\employee.mdf"";Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                string query = "DELETE FROM employees WHERE id = @id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", employeeId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int employeeId = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["Id"].Value);
                using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Acer Nitro 5\LocalDB\employee.mdf"";Integrated Security=True;Connect Timeout=30"))
                {
                    string query = @"
                        SELECT 
                            e.id, 
                            e.full_name, 
                            e.username, 
                            e.password_hash, 
                            el.level_name AS english_level, 
                            p.position_name AS position, 
                            ex.experience_name AS experience, 
                            e.communication_skills_id 
                        FROM 
                            employees e
                            JOIN english_levels el ON e.english_level_id = el.id
                            JOIN positions p ON e.position_id = p.id
                            JOIN experiences ex ON e.experience_id = ex.id
                        WHERE e.id = @Id";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Id", employeeId);

                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        EmployeeProfileForm profileForm = new EmployeeProfileForm(
                            Convert.ToInt32(reader["id"]),
                            reader["full_name"].ToString(),
                            reader["username"].ToString(),
                            reader["english_level"].ToString(),
                            reader["position"].ToString(),
                            reader["experience"].ToString()
                        );
                        profileForm.ShowDialog();
                    }
                }
            }
        }


        private void Update_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int employeeId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["Id"].Value);
                using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Acer Nitro 5\LocalDB\employee.mdf"";Integrated Security=True;Connect Timeout=30"))
                {
                    string query = @"
                SELECT 
                    e.id, 
                    e.full_name, 
                    e.username, 
                    e.password_hash, 
                    el.level_name AS english_level, 
                    p.position_name AS position, 
                    ex.experience_name AS experience, 
                    e.communication_skills_id 
                FROM 
                    employees e
                    JOIN english_levels el ON e.english_level_id = el.id
                    JOIN positions p ON e.position_id = p.id
                    JOIN experiences ex ON e.experience_id = ex.id
                WHERE 
                    e.id = @Id";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Id", employeeId);

                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        UpdateEmployee editForm = new UpdateEmployee(
                            (int)reader["id"],
                            reader["full_name"].ToString(),
                            reader["username"].ToString(),
                            reader["password_hash"].ToString(),
                            reader["english_level"].ToString(),
                            reader["position"].ToString(),
                            reader["experience"].ToString(),
                            (int)reader["communication_skills_id"]
                        );
                        editForm.ShowDialog();
                        LoadEmployees();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select an employee to update.");
            }
        }


        private void label8_Click(object sender, EventArgs e)
        {

        }
        private int GetTotalEmployeesCount()
        {
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Acer Nitro 5\LocalDB\employee.mdf"";Integrated Security=True;Connect Timeout=30"))
            {
                string query = "SELECT COUNT(*) FROM employees";
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                int count = (int)cmd.ExecuteScalar();
                return count;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            LoadEmployees();
            label8.Text = Convert.ToString(GetTotalEmployeesCount());
        }
    }
}
