﻿namespace SkillsManagementSystem
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            panel1 = new Panel();
            button1 = new Button();
            lblStudy = new Label();
            lblEmployee = new Label();
            employeeBoard3 = new EmployeeBoard();
            courcesWindow1 = new CourcesWindow();
            panel2 = new Panel();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Cursor = Cursors.Hand;
            label1.Font = new Font("Microsoft JhengHei", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(1058, -2);
            label1.Name = "label1";
            label1.Size = new Size(44, 43);
            label1.TabIndex = 2;
            label1.Text = "×";
            label1.Click += label1_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(button1);
            panel1.Controls.Add(lblStudy);
            panel1.Controls.Add(lblEmployee);
            panel1.Location = new Point(-1, -2);
            panel1.Name = "panel1";
            panel1.Size = new Size(250, 703);
            panel1.TabIndex = 6;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(34, 109, 170);
            button1.Cursor = Cursors.Hand;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(19, 70, 111);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            button1.ForeColor = SystemColors.ButtonHighlight;
            button1.Location = new Point(42, 645);
            button1.Name = "button1";
            button1.Size = new Size(123, 43);
            button1.TabIndex = 7;
            button1.Text = "Sign Out";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // lblStudy
            // 
            lblStudy.AutoSize = true;
            lblStudy.BackColor = Color.FromArgb(232, 237, 242);
            lblStudy.Cursor = Cursors.Hand;
            lblStudy.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            lblStudy.Image = Properties.Resources.Vector___0__3_;
            lblStudy.ImageAlign = ContentAlignment.MiddleLeft;
            lblStudy.Location = new Point(35, 31);
            lblStudy.Name = "lblStudy";
            lblStudy.Padding = new Padding(10, 10, 50, 10);
            lblStudy.Size = new Size(187, 51);
            lblStudy.TabIndex = 10;
            lblStudy.Text = "     Study    ";
            lblStudy.TextAlign = ContentAlignment.MiddleRight;
            lblStudy.Click += lblStudy_Click;
            // 
            // lblEmployee
            // 
            lblEmployee.AutoSize = true;
            lblEmployee.BackColor = Color.FromArgb(232, 237, 242);
            lblEmployee.Cursor = Cursors.Hand;
            lblEmployee.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            lblEmployee.Image = Properties.Resources.Vector___0;
            lblEmployee.ImageAlign = ContentAlignment.MiddleLeft;
            lblEmployee.Location = new Point(35, 82);
            lblEmployee.Name = "lblEmployee";
            lblEmployee.Padding = new Padding(10);
            lblEmployee.Size = new Size(188, 51);
            lblEmployee.TabIndex = 7;
            lblEmployee.Text = "     Employees  ";
            lblEmployee.TextAlign = ContentAlignment.MiddleRight;
            lblEmployee.Click += lblEmployee_Click;
            // 
            // employeeBoard3
            // 
            employeeBoard3.Location = new Point(247, 29);
            employeeBoard3.Name = "employeeBoard3";
            employeeBoard3.Size = new Size(1070, 840);
            employeeBoard3.TabIndex = 8;
            employeeBoard3.Load += employeeBoard3_Load;
            // 
            // courcesWindow1
            // 
            courcesWindow1.Location = new Point(241, 26);
            courcesWindow1.Name = "courcesWindow1";
            courcesWindow1.Size = new Size(1070, 840);
            courcesWindow1.TabIndex = 7;
            // 
            // panel2
            // 
            panel2.Location = new Point(245, 31);
            panel2.Name = "panel2";
            panel2.Size = new Size(1070, 840);
            panel2.TabIndex = 9;

            this.panel2.Size = new System.Drawing.Size(1070, 840);

            // Add the panel to the form's controls
            this.Controls.Add(this.panel2);
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1100, 700);
            Controls.Add(label1);
            Controls.Add(employeeBoard3);
            Controls.Add(courcesWindow1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "🕓";
            Load += MainForm_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Panel panel1;
        private Label lblEmployee;
        private Label lblStudy;
        private Button button1;
        private EmployeeBoard employeeBoard1;
        private EmployeeBoard employeeBoard2;
        private EmployeeBoard employeeBoard3;
        private CourcesWindow courcesWindow1;
        private Panel panel2;
    }
}