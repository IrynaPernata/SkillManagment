﻿namespace SkillsManagementSystem
{
    partial class EmployeeProfileForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            fullName = new Label();
            lblFullName = new Label();
            username = new Label();
            lblPosition = new Label();
            lblExperience = new Label();
            lblEnglishLevel = new Label();
            label2 = new Label();
            label3 = new Label();
            Experience = new Label();
            label4 = new Label();
            assignedCoursesGridView = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)assignedCoursesGridView).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Cursor = Cursors.Hand;
            label1.Font = new Font("Microsoft JhengHei", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(534, -8);
            label1.Name = "label1";
            label1.Size = new Size(44, 43);
            label1.TabIndex = 3;
            label1.Text = "×";
            label1.Click += label1_Click;
            // 
            // fullName
            // 
            fullName.AutoSize = true;
            fullName.Location = new Point(86, 59);
            fullName.Name = "fullName";
            fullName.Size = new Size(0, 20);
            fullName.TabIndex = 4;
            // 
            // lblFullName
            // 
            lblFullName.AutoSize = true;
            lblFullName.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            lblFullName.Location = new Point(58, 59);
            lblFullName.Name = "lblFullName";
            lblFullName.Size = new Size(176, 38);
            lblFullName.TabIndex = 5;
            lblFullName.Text = "lblFullName";
            // 
            // username
            // 
            username.AutoSize = true;
            username.Font = new Font("Segoe UI", 9F, FontStyle.Italic, GraphicsUnit.Point, 204);
            username.Location = new Point(58, 97);
            username.Name = "username";
            username.Size = new Size(93, 20);
            username.TabIndex = 6;
            username.Text = " lblUsername";
            // 
            // lblPosition
            // 
            lblPosition.AutoSize = true;
            lblPosition.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            lblPosition.Location = new Point(178, 163);
            lblPosition.Name = "lblPosition";
            lblPosition.Size = new Size(107, 28);
            lblPosition.TabIndex = 7;
            lblPosition.Text = "lblPosition";
            // 
            // lblExperience
            // 
            lblExperience.AutoSize = true;
            lblExperience.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblExperience.Location = new Point(178, 214);
            lblExperience.Name = "lblExperience";
            lblExperience.Size = new Size(132, 28);
            lblExperience.TabIndex = 8;
            lblExperience.Text = "lblExperience";
            // 
            // lblEnglishLevel
            // 
            lblEnglishLevel.AutoSize = true;
            lblEnglishLevel.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            lblEnglishLevel.Location = new Point(178, 271);
            lblEnglishLevel.Name = "lblEnglishLevel";
            lblEnglishLevel.Size = new Size(146, 28);
            lblEnglishLevel.TabIndex = 10;
            lblEnglishLevel.Text = "lblEnglishLevel";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.Location = new Point(58, 163);
            label2.Name = "label2";
            label2.Size = new Size(85, 28);
            label2.TabIndex = 11;
            label2.Text = "Position";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label3.Location = new Point(58, 271);
            label3.Name = "label3";
            label3.Size = new Size(77, 28);
            label3.TabIndex = 13;
            label3.Text = "English";
            // 
            // Experience
            // 
            Experience.AutoSize = true;
            Experience.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            Experience.Location = new Point(58, 214);
            Experience.Name = "Experience";
            Experience.Size = new Size(110, 28);
            Experience.TabIndex = 12;
            Experience.Text = "Experience";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold);
            label4.Location = new Point(58, 358);
            label4.Name = "label4";
            label4.Size = new Size(200, 32);
            label4.TabIndex = 14;
            label4.Text = "Assigned cources";
            // 
            // assignedCoursesGridView
            // 
            assignedCoursesGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            assignedCoursesGridView.Location = new Point(58, 405);
            assignedCoursesGridView.Name = "assignedCoursesGridView";
            assignedCoursesGridView.RowHeadersWidth = 51;
            assignedCoursesGridView.Size = new Size(488, 234);
            assignedCoursesGridView.TabIndex = 15;
            assignedCoursesGridView.CellContentClick += assignedCoursesGridView_CellContentClick;
            // 
            // EmployeeProfileForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(570, 678);
            Controls.Add(assignedCoursesGridView);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(Experience);
            Controls.Add(label2);
            Controls.Add(lblEnglishLevel);
            Controls.Add(lblExperience);
            Controls.Add(lblPosition);
            Controls.Add(username);
            Controls.Add(lblFullName);
            Controls.Add(fullName);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "EmployeeProfileForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EmployeeProfileForm";
            ((System.ComponentModel.ISupportInitialize)assignedCoursesGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label fullName;
        private Label lblFullName;
        private Label username;
        private Label lblPosition;
        private Label lblExperience;
        private Label lblEnglishLevel;
        private Label label2;
        private Label label3;
        private Label Experience;
        private Label label4;
        private Panel panel1;
        private FlowLayoutPanel flowLayoutPanel1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private PictureBox pictureBox9;
        private PictureBox pictureBox10;
        private PictureBox pictureBox11;
        private PictureBox pictureBox12;
        private PictureBox pictureBox13;
        private PictureBox pictureBox14;
        private PictureBox pictureBox15;
        private PictureBox pictureBox16;
        private PictureBox pictureBox17;
        private PictureBox pictureBox18;
        private PictureBox pictureBox19;
        private PictureBox pictureBox20;
        private DataGridView assignedCoursesGridView;
    }
}