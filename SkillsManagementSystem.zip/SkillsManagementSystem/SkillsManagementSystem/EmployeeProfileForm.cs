﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace SkillsManagementSystem
{
    public partial class EmployeeProfileForm : Form
    {
        private int _employeeId;
        private string _fullName;
        private string _username;
        private string _englishLevel;
        private string _position;
        private string _experience;
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Acer Nitro 5\LocalDB\employee.mdf"";Integrated Security=True;Connect Timeout=30";

        public EmployeeProfileForm(int employeeId, string fullName, string username, string englishLevel, string position, string experience)
        {
            InitializeComponent();

            _employeeId = employeeId;
            _fullName = fullName;
            _username = username;
            _englishLevel = englishLevel;
            _position = position;
            _experience = experience;
            LoadAssignedCourses();
            LoadEmployeeDetails();
        }

        private void LoadEmployeeDetails()
        {
            lblFullName.Text = _fullName;
            username.Text = _username;
            lblEnglishLevel.Text = _englishLevel;
            lblPosition.Text = _position;
            lblExperience.Text = _experience;
        }

        private void LoadAssignedCourses()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"
                SELECT 
                    c.course_name, 
                    c.description 
                FROM 
                    assignments_courses ac
                    JOIN courses c ON ac.course_id = c.course_id
                WHERE 
                    ac.employee_id = @employeeId";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@employeeId", _employeeId);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable coursesTable = new DataTable();
                adapter.Fill(coursesTable);

                assignedCoursesGridView.DataSource = coursesTable;
            }
        }





        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void assignedCoursesGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
