﻿namespace SkillsManagementSystem
{
    partial class CourcesWindow
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewCourse = new DataGridView();
            Delete = new Button();
            Add = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridViewCourse).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewCourse
            // 
            dataGridViewCourse.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCourse.Location = new Point(42, 121);
            dataGridViewCourse.Name = "dataGridViewCourse";
            dataGridViewCourse.RowHeadersWidth = 51;
            dataGridViewCourse.Size = new Size(766, 501);
            dataGridViewCourse.TabIndex = 0;
            dataGridViewCourse.CellContentClick += dataGridView1_CellContentClick;
            dataGridViewCourse.CellMouseDoubleClick += coursesGridView_CellMouseDoubleClick;
            // 
            // Delete
            // 
            Delete.BackColor = Color.Firebrick;
            Delete.Cursor = Cursors.Hand;
            Delete.FlatAppearance.BorderSize = 0;
            Delete.FlatAppearance.MouseOverBackColor = Color.FromArgb(34, 109, 170);
            Delete.FlatStyle = FlatStyle.Flat;
            Delete.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            Delete.ForeColor = SystemColors.ButtonHighlight;
            Delete.Location = new Point(574, 53);
            Delete.Name = "Delete";
            Delete.Size = new Size(111, 43);
            Delete.TabIndex = 15;
            Delete.Text = "Delete";
            Delete.UseVisualStyleBackColor = false;
            Delete.Click += Delete_Click;
            // 
            // Add
            // 
            Add.BackColor = Color.LimeGreen;
            Add.Cursor = Cursors.Hand;
            Add.FlatAppearance.BorderSize = 0;
            Add.FlatAppearance.MouseOverBackColor = Color.FromArgb(34, 109, 170);
            Add.FlatStyle = FlatStyle.Flat;
            Add.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            Add.ForeColor = SystemColors.ButtonHighlight;
            Add.Location = new Point(410, 53);
            Add.Name = "Add";
            Add.Size = new Size(111, 43);
            Add.TabIndex = 16;
            Add.Text = "Add";
            Add.UseVisualStyleBackColor = false;
            Add.Click += Add_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.Location = new Point(42, 36);
            label1.Name = "label1";
            label1.Size = new Size(300, 38);
            label1.TabIndex = 17;
            label1.Text = "Educational Materials";
            label1.Click += label1_Click;
            // 
            // CourcesWindow
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(label1);
            Controls.Add(Add);
            Controls.Add(Delete);
            Controls.Add(dataGridViewCourse);
            Name = "CourcesWindow";
            Size = new Size(856, 672);
            Load += CourcesWindow_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewCourse).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridViewCourse;
        private Button Delete;
        private Button Add;
        private Label label1;
    }
}
