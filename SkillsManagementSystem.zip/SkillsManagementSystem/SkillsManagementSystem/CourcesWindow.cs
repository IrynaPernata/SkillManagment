﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SkillsManagementSystem
{
    public partial class CourcesWindow : UserControl
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Acer Nitro 5\LocalDB\employee.mdf"";Integrated Security=True;Connect Timeout=30";
        public CourcesWindow()
        {
            InitializeComponent();
            LoadCourses();
        }
        private void LoadCourses()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM courses";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable coursesTable = new DataTable();
                adapter.Fill(coursesTable);
                dataGridViewCourse.DataSource = coursesTable;
            }
        }


        private void CourcesWindow_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Delete_Click(object sender, EventArgs e)
        {

            if (dataGridViewCourse.SelectedRows.Count > 0)
            {
                int courseId = Convert.ToInt32(dataGridViewCourse.SelectedRows[0].Cells["course_id"].Value);
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM courses WHERE course_id = @courseId";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@courseId", courseId);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
                MessageBox.Show("Course deleted successfully!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadCourses();
            }
            else
            {
                MessageBox.Show("Please select a course to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Add_Click(object sender, EventArgs e)
        {
            AddCourse addCourseForm = new AddCourse();
            addCourseForm.ShowDialog();
            LoadCourses();
        }
       

        private void coursesGridView_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int courseId = Convert.ToInt32(dataGridViewCourse.Rows[e.RowIndex].Cells["course_id"].Value);
                CourseAssignForm assignCourseForm = new CourseAssignForm(courseId);
                assignCourseForm.ShowDialog();
                LoadCourses();
            }
        }
    }
}
