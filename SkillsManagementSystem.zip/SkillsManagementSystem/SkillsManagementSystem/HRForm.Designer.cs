﻿namespace SkillsManagementSystem
{
    partial class HRForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HRForm));
            button2 = new Button();
            button1 = new Button();
            ShowPasswordBox = new CheckBox();
            passwordTB = new TextBox();
            PasswordLabel = new Label();
            usernameTextBox = new TextBox();
            label3 = new Label();
            label2 = new Label();
            panel1 = new Panel();
            label4 = new Label();
            exit = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(19, 93, 102);
            button2.Cursor = Cursors.Hand;
            button2.FlatAppearance.BorderColor = Color.DarkSlateGray;
            button2.FlatAppearance.MouseDownBackColor = Color.FromArgb(26, 77, 46);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button2.ForeColor = Color.White;
            button2.Location = new Point(273, 306);
            button2.Name = "button2";
            button2.Size = new Size(119, 52);
            button2.TabIndex = 18;
            button2.Text = "SIGN IN";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(122, 178, 178);
            button1.Cursor = Cursors.Hand;
            button1.FlatAppearance.BorderColor = Color.DarkSlateGray;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseDownBackColor = Color.FromArgb(26, 77, 46);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Arial", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button1.ForeColor = Color.White;
            button1.Location = new Point(410, 306);
            button1.Name = "button1";
            button1.Size = new Size(119, 52);
            button1.TabIndex = 17;
            button1.Text = "SIGN UP";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // ShowPasswordBox
            // 
            ShowPasswordBox.AutoSize = true;
            ShowPasswordBox.Cursor = Cursors.Hand;
            ShowPasswordBox.FlatStyle = FlatStyle.Popup;
            ShowPasswordBox.Font = new Font("Arial", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            ShowPasswordBox.ForeColor = Color.FromArgb(64, 64, 64);
            ShowPasswordBox.Location = new Point(409, 261);
            ShowPasswordBox.Name = "ShowPasswordBox";
            ShowPasswordBox.Size = new Size(119, 20);
            ShowPasswordBox.TabIndex = 16;
            ShowPasswordBox.Text = "Show Password";
            ShowPasswordBox.UseVisualStyleBackColor = true;
            ShowPasswordBox.CheckedChanged += ShowPasswordBox_CheckedChanged;
            // 
            // passwordTB
            // 
            passwordTB.Cursor = Cursors.IBeam;
            passwordTB.Font = new Font("Microsoft YaHei", 10.2F);
            passwordTB.Location = new Point(270, 220);
            passwordTB.Multiline = true;
            passwordTB.Name = "passwordTB";
            passwordTB.ShortcutsEnabled = false;
            passwordTB.Size = new Size(261, 35);
            passwordTB.TabIndex = 15;
            passwordTB.TextChanged += passwordTextBox_TextChanged;
            // 
            // PasswordLabel
            // 
            PasswordLabel.AutoSize = true;
            PasswordLabel.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            PasswordLabel.ForeColor = Color.FromArgb(64, 64, 64);
            PasswordLabel.Location = new Point(270, 191);
            PasswordLabel.Name = "PasswordLabel";
            PasswordLabel.Size = new Size(98, 23);
            PasswordLabel.TabIndex = 14;
            PasswordLabel.Text = "Password";
            // 
            // usernameTextBox
            // 
            usernameTextBox.Cursor = Cursors.IBeam;
            usernameTextBox.Font = new Font("Microsoft YaHei", 10.2F);
            usernameTextBox.Location = new Point(270, 145);
            usernameTextBox.Multiline = true;
            usernameTextBox.Name = "usernameTextBox";
            usernameTextBox.Size = new Size(261, 35);
            usernameTextBox.TabIndex = 13;
            usernameTextBox.TextChanged += usernameTextBox_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label3.ForeColor = Color.FromArgb(64, 64, 64);
            label3.Location = new Point(270, 116);
            label3.Name = "label3";
            label3.Size = new Size(99, 23);
            label3.TabIndex = 12;
            label3.Text = "Username";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.ForeColor = Color.FromArgb(0, 60, 67);
            label2.Location = new Point(270, 51);
            label2.Name = "label2";
            label2.Size = new Size(212, 35);
            label2.TabIndex = 11;
            label2.Text = "HR`s Account";
            label2.Click += label2_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(153, 188, 133);
            panel1.BackgroundImage = (Image)resources.GetObject("panel1.BackgroundImage");
            panel1.BackgroundImageLayout = ImageLayout.None;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(label4);
            panel1.Dock = DockStyle.Left;
            panel1.ForeColor = Color.DarkSeaGreen;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(223, 400);
            panel1.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.FromArgb(0, 0, 0, 0);
            label4.Font = new Font("Tahoma", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label4.ForeColor = Color.Azure;
            label4.Location = new Point(16, 18);
            label4.Name = "label4";
            label4.Size = new Size(186, 102);
            label4.TabIndex = 0;
            label4.Text = "Skills \r\nManagement \r\nSystem";
            // 
            // exit
            // 
            exit.AutoSize = true;
            exit.Cursor = Cursors.Hand;
            exit.Font = new Font("Microsoft JhengHei", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            exit.Location = new Point(535, -4);
            exit.Name = "exit";
            exit.Size = new Size(44, 43);
            exit.TabIndex = 19;
            exit.Text = "×";
            exit.Click += exit_Click;
            // 
            // HRForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Menu;
            ClientSize = new Size(575, 400);
            Controls.Add(exit);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(ShowPasswordBox);
            Controls.Add(passwordTB);
            Controls.Add(PasswordLabel);
            Controls.Add(usernameTextBox);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "HRForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form2";
            Load += HRForm_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button1;
        private CheckBox ShowPasswordBox;
        private TextBox passwordTB;
        private Label PasswordLabel;
        private TextBox usernameTextBox;
        private Label label3;
        private Label label2;
        private Panel panel1;
        private Label label4;
        private Label exit;
    }
}