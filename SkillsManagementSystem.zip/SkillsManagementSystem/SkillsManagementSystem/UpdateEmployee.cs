﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace SkillsManagementSystem
{
    public partial class UpdateEmployee : Form
    {
        private readonly int _employeeId;
        private SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Acer Nitro 5\LocalDB\employee.mdf"";Integrated Security=True;Connect Timeout=30");
        private List<string> photoFilePaths = new List<string>();

        public UpdateEmployee(int employeeId, string fullName, string username, string password, string englishLevel, string position, string experience, int communicationSkillsId)
        {
            InitializeComponent();
            _employeeId = employeeId;
            txtFullName.Text = fullName;
            txtUsername.Text = username;
            txtPassword.Text = password;
            LoadEnglishLevels(englishLevel);
            LoadPositions(position);
            LoadExperiences(experience);
            numCommunicationRate.Value = communicationSkillsId;

            
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

  
        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFullName.Text) ||
                string.IsNullOrWhiteSpace(txtUsername.Text) ||
                string.IsNullOrWhiteSpace(txtPassword.Text) ||
                cmbEnglishLevel.SelectedIndex == -1 ||
                Position.SelectedIndex == -1 ||
                Experience.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill in all the required fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (conn)
            {
                string query = @"
                UPDATE employees SET 
                    full_name = @FullName, 
                    username = @Username, 
                    password_hash = @Password, 
                    english_level_id = @EnglishLevelId,
                    position_id = @PositionId,
                    experience_id = @ExperienceId,
                    communication_skills_id = @CommunicationSkillsId
                WHERE id = @Id";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@FullName", txtFullName.Text);
                cmd.Parameters.AddWithValue("@Username", txtUsername.Text);
                cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
                cmd.Parameters.AddWithValue("@EnglishLevelId", cmbEnglishLevel.SelectedValue);
                cmd.Parameters.AddWithValue("@PositionId", Position.SelectedValue);
                cmd.Parameters.AddWithValue("@ExperienceId", Experience.SelectedValue);
                cmd.Parameters.AddWithValue("@CommunicationSkillsId", numCommunicationRate.Value);
                cmd.Parameters.AddWithValue("@Id", _employeeId);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }

            MessageBox.Show("Employee updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            var employeeBoard = Application.OpenForms.OfType<EmployeeBoard>().FirstOrDefault();
            employeeBoard?.LoadEmployees();

            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtFullName.Clear();
            txtUsername.Clear();
            txtPassword.Clear();
            cmbEnglishLevel.SelectedIndex = -1;
            Position.SelectedIndex = -1;
            Experience.SelectedIndex = -1;
            numCommunicationRate.Value = 0;
        }

        private void LoadPositions(string selectedPosition)
        {
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Acer Nitro 5\LocalDB\employee.mdf"";Integrated Security=True;Connect Timeout=30"))
            {
                string query = "SELECT id, position_name FROM positions";
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(reader);

                Position.DataSource = dt;
                Position.DisplayMember = "position_name";
                Position.ValueMember = "id";

                if (!string.IsNullOrEmpty(selectedPosition))
                {
                    Position.SelectedIndex = Position.FindStringExact(selectedPosition);
                }
            }
        }

        private void LoadExperiences(string selectedExperience)
        {
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Acer Nitro 5\LocalDB\employee.mdf"";Integrated Security=True;Connect Timeout=30"))
            {
                string query = "SELECT id, experience_name FROM experiences";
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(reader);

                Experience.DataSource = dt;
                Experience.DisplayMember = "experience_name";
                Experience.ValueMember = "id";

                if (!string.IsNullOrEmpty(selectedExperience))
                {
                    Experience.SelectedIndex = Experience.FindStringExact(selectedExperience);
                }
            }
        }

        private void LoadEnglishLevels(string selectedLevel)
        {
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Acer Nitro 5\LocalDB\employee.mdf"";Integrated Security=True;Connect Timeout=30 "))
            {
                string query = "SELECT id, level_name FROM english_levels";
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(reader);

                cmbEnglishLevel.DataSource = dt;
                cmbEnglishLevel.DisplayMember = "level_name";
                cmbEnglishLevel.ValueMember = "id";

                if (!string.IsNullOrEmpty(selectedLevel))
                {
                    cmbEnglishLevel.SelectedIndex = cmbEnglishLevel.FindStringExact(selectedLevel);
                }
            }
        }

      
    }
}
